
int multiply60(int a);

