#!/usr/bin/env ruby
#
# Put description here
#
# 
# 
# 
#

require 'swig_assert'
require 'abstract_virtual'

include Abstract_virtual

swig_assert('d = D.new')
swig_assert('e = E.new')
