#!/usr/bin/env ruby
#
# Tests for function_typedef.i
#
#

require 'swig_assert'
require 'function_typedef'
include Function_typedef

# Hmm... not sure how to test this.
