#!/usr/bin/env ruby
#
# Put description here
#
# 
# 
# 
#

require 'swig_assert'

require 'using1'

raise RuntimeError unless Using1.spam(37) == 37

